PIXL8.tocExpandHandler = function() {


    // our team dropped content
    $('.js-toc-expand')
        .on('click', '.article-block a',function(e) {
            e.preventDefault();
            var item_row = 0, // $(this).closest('.article-block').data('smrow');
                item_content = $(this).closest('.article-block').find('.hidden-details').html(),
                top_offset = 0;
            // console.log(item_row);


            if( $(this).closest('.article-block').hasClass('open') ) {
                $('.js-toc-expand .article-block').removeClass('open item-row');

                $('.js-toc-expand').find('.dropped-content').slideUp( function() {
                    $('.js-toc-expand').find('.dropped-wrapper, .before-drop').remove();
                });
            }
            else if( $(this).closest('.article-block').hasClass('item-row') ) {
                $('.js-toc-expand .article-block').removeClass('open');

                $(this).closest('.article-block').addClass('open');

            }

            else {
                $('.article-block').removeClass('open item-row');
                $('.js-toc-expand').find('.dropped-wrapper, .before-drop').remove();




                if( PIXL8.fn.viewport().width > 991 ) {
                    item_row = $(this).closest('.article-block').addClass('open').data('smrow');

                    $('.js-toc-expand div[data-smrow="'+item_row+'"]').addClass('item-row').last().after('<div class="clearfix before-drop"></div><div class="dropped-wrapper"><div class="dropped-content"></div></div>');


                }
                else if( PIXL8.fn.viewport().width > 767 ) {
                    item_row = $(this).closest('.article-block').addClass('open').data('xsrow');
                    $('.js-toc-expand div[data-xsrow="'+item_row+'"]').addClass('item-row').last().after('<div class="clearfix before-drop"></div><div class="dropped-wrapper"><div class="dropped-content"></div></div>');

                }
                else {
                    $(this).closest('.article-block').addClass('open item-row').after('<div class="clearfix before-drop"></div><div class="dropped-wrapper"><div class="dropped-content"></div></div>');

                }
            }

            top_offset = $('.js-toc-expand .article-block.open').offset().top - 20;

            $('.dropped-content').html(item_content).slideDown(200, function() {
	            $('html, body').animate({
	                scrollTop: top_offset
	            }, 200);
            });


        });

};

( function( $ ) {

	$( document ).ready( function() {

		PIXL8.tocExpandHandler();

	} );

} )( jQuery );