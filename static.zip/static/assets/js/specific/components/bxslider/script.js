PIXL8.bxsliderHandler = function() {

	$('.js-bxslider').each(function(i) {
		var $slider = $(this);
		if( $slider.find('.bxslider-item').length > 1 ){

			$slider.bxSlider({
				mode: 'fade',
				captions: false,
				nextText: '<span class="icon-aae-right"></span>',
				prevText: '<span class="icon-aae-left"></span>',
				pager: false,
				onSliderLoad: function(currentIndex) {
					var imgH = $slider.find('.bxslider-item img').height(),
						imgW = $slider.find('.bxslider-item img').width();
					imgH = imgH / 2;
					$slider.closest('.bx-wrapper').find('.bx-controls-direction a').css('top', imgH+'px');
					$slider.closest('.bx-wrapper').find('.bxslider-item').css('width', imgW+'px');
					$slider.closest('.bx-wrapper').css('width', imgW+'px');
					// console.log($slider.find('.bxslider-item img').height());
				}
			});
		}

	});

};

( function( $ ) {

	$( document ).ready( function() {

		PIXL8.bxsliderHandler();

	} );

} )( jQuery );