PIXL8.validateFormHandler = function() {

	$("#commentForm, #checkboxRadioForm, #selectForm, #fileForm").validate({
		errorElement   : 'div',
		errorClass     : 'alert alert-danger error',
		validClass     : 'alert alert-success',
		errorPlacement : function(error, element) {
			if ( element.attr("type") == "file" || element.attr("type") == "checkbox" || element.attr("type") == "radio" || element.is("select") ) {
				error.insertAfter( element.closest(".form-field") );
			} else {
				error.insertAfter(element);
			}
		},
		highlight      : function(element, errorClass) {
			if ( $(element).parent().hasClass("checkbox") || $(element).parent().hasClass("radio") || $(element).attr("type") == "file" ) {
				return;
			} else {
				$(element).closest(".form-group").addClass("has-error");
			}
		},
		unhighlight    : function(element, errorClass) {
			if ( $(element).parent().hasClass("checkbox") || $(element).parent().hasClass("radio") || $(element).attr("type") == "file" ) {
				return;
			} else {
				$(element).closest(".form-group").removeClass("has-error");
			}
		}
	});

	$("#signupForm").validate({
		errorElement : 'div',
		errorClass   : 'alert alert-danger error',
		validClass   : 'alert alert-success',
		rules        : {
			firstname        : "required",
			lastname         : "required",
			username         : {
				required     : true,
				minlength    : 2
			},
			password         : {
				required     : true,
				minlength    : 5
			},
			confirm_password : {
				required     : true,
				minlength    : 5,
				equalTo      : "#password"
			},
			email            : {
				required     : true,
				email        : true
			},
			topic            : {
				required     : "#newsletter:checked",
				minlength    : 2
			},
			agree            : "required"
		},
		messages: {
			firstname        : "Please enter your firstname",
			lastname         : "Please enter your lastname",
			username         : {
				required     : "Please enter a username",
				minlength    : "Your username must consist of at least 2 characters"
			},
			password         : {
				required     : "Please provide a password",
				minlength    : "Your password must be at least 5 characters long"
			},
			confirm_password : {
				required     : "Please provide a password",
				minlength    : "Your password must be at least 5 characters long",
				equalTo      : "Please enter the same password as above"
			},
			email            : "Please enter a valid email address",
			agree            : "Please accept our policy",
			topic            : "Please select at least 2 topics"
		},
		errorPlacement : function(error, element) {
			if ( element.attr("type") == "file" || element.attr("type") == "checkbox" || element.attr("type") == "radio" || element.is("select") ) {
				error.insertAfter( element.closest(".form-field") );
			} else {
				error.insertAfter(element);
			}
		},
		highlight: function(element, errorClass) {
			if ( $(element).parent().hasClass("checkbox") || $(element).parent().hasClass("radio") || $(element).attr("type") == "file" ) {
				return;
			} else {
				$(element).closest(".form-group").addClass("has-error");
			}
		},
		unhighlight: function(element, errorClass) {
			if ( $(element).parent().hasClass("checkbox") || $(element).parent().hasClass("radio") || $(element).attr("type") == "file" ) {
				return;
			} else {
				$(element).closest(".form-group").removeClass("has-error");
			}
		}
	});

	$("#customMessageForm").validate({
		errorElement : 'div',
		errorClass   : 'alert alert-danger error',
		validClass   : 'alert alert-success',
		highlight    : function(element, errorClass) {
			if ( $(element).parent().hasClass("checkbox") || $(element).parent().hasClass("radio") || $(element).attr("type") == "file" ) {
				return;
			} else {
				$(element).closest(".form-group").addClass("has-error");
			}
		},
		unhighlight  : function(element, errorClass) {
			if ( $(element).parent().hasClass("checkbox") || $(element).parent().hasClass("radio") || $(element).attr("type") == "file" ) {
				return;
			} else {
				$(element).closest(".form-group").removeClass("has-error");
			}
		}
	});

	$("#customMessageForm2").validate({
		errorElement : 'div',
		errorClass   : 'alert alert-danger error',
		validClass   : 'alert alert-success',
		messages     : {
			email: {
				required : '请输入您的电子邮件地址',
				email    : '请输入有效的电子邮件地址'
			}
		},
		highlight    : function(element, errorClass) {
			if ( $(element).parent().hasClass("checkbox") || $(element).parent().hasClass("radio") || $(element).attr("type") == "file" ) {
				return;
			} else {
				$(element).closest(".form-group").addClass("has-error");
			}
		},
		unhighlight  : function(element, errorClass) {
			if ( $(element).parent().hasClass("checkbox") || $(element).parent().hasClass("radio") || $(element).attr("type") == "file" ) {
				return;
			} else {
				$(element).closest(".form-group").removeClass("has-error");
			}
		}
	});

};

( function( $ ) {

	$( document ).ready( function() {

		PIXL8.validateFormHandler();

	} );

} )( jQuery );