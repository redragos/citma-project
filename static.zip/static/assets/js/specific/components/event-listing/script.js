PIXL8.stickyFilterHandler = function( $container ) {

    if( PIXL8.fn.viewport().width >= 768 ) {
        $( ".toggle-tabs-nav a", $container ).click(function(e) {
            stickyScroll();
        });
        stickyScroll();
    }

    function stickyScroll() {
        $('.event-listing-filtered').each(function() {
            var event_parent = $(this);
            var top = $(this).find('.sticky-widget').offset().top;
            var event_listing = ($(this).offset().top +  $(this).height());
            var sticky_nav = event_parent.find('.sticky-widget');

            $(window).scroll(function (event) {

                var y = $(this).scrollTop();

                if ( y >= top  && y < (event_listing - sticky_nav.height())) {
                   sticky_nav.addClass('active-sticky').css('top', (y - top ) );
        
                }  else if(  sticky_nav.hasClass('active-sticky') && y >= (event_listing - sticky_nav.height()) ) {
                    sticky_nav.css('top', (( event_listing -  sticky_nav.height() ) - top ) );  
                    
                } else {
                    event_parent.find('.sticky-widget').removeClass('active-sticky').removeAttr('style');
                
                }
                
            });

            $(this).find('.widget-event-calendar li a[href*="#"]').on('click', function(e) {
                e.preventDefault();

                if( !$(this).parent().hasClass('is-active')) {
                    $(this).parent().siblings().removeClass('is-active');
                    $(this).parent().addClass('is-active');
                    var target = $(this.hash);
                    target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
                    if (target.length) {
                        // Only prevent default if animation is actually gonna happen
                        event.preventDefault();
                        $('html, body').animate({
                          scrollTop: target.offset().top
                        }, 600);
                    }
                } 
        
            });
        });
    }
    
};

( function( $ ) {

    $( document ).ready( function() {

        PIXL8.stickyFilterHandler( $("body") );

    } );

} )( jQuery );


