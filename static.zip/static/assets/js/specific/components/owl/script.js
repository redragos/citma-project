PIXL8.owlHandler = function() {

	
    function jsBannerHeight(listing, item) {

        // $(item).removeAttr('style');
        $(item).height('auto');

        $(listing).each(function() {

            var currentTallest = 0,
                 currentRowStart = 0,
                 rowDivs = new Array(),
                 $el,
                 topPosition = 0;
             $(this).find(item).each(function() {


               $el = $(this);
               // $el.removeAttr('style');
               topPosition = $el.position().top;

               if (currentRowStart != topPosition) {

                 // we just came to a new row.  Set all the heights on the completed row
                 for (currentDiv = 0 ; currentDiv < rowDivs.length ; currentDiv++) {
                   rowDivs[currentDiv].height(currentTallest);
                 }

                 // set the variables for the new row
                 rowDivs.length = 0; // empty the array
                 currentRowStart = topPosition;
                 currentTallest = $el.height();
                 rowDivs.push($el);

               } else {

                 // another div on the current row.  Add it to the list and check if it's taller
                 rowDivs.push($el);
                 currentTallest = (currentTallest < $el.height()) ? ($el.height()) : (currentTallest);

              }

              // do the last row
               for (currentDiv = 0 ; currentDiv < rowDivs.length ; currentDiv++) {
                 rowDivs[currentDiv].height(currentTallest);
               }

             });​
        });
    }
    
    PIXL8.fn.addDebounceResize(function() {
        jsBannerHeight('.js-bannerslider', '.bannerslider-item .details');
    });

	// js-bannerslider
	if( $(".js-bannerslider .bannerslider-item").length > 1 ) {
        var $owl = $(".js-bannerslider");
        var autoPlay = $owl.data( 'scroll' );

		$owl.owlCarousel({
		    items:              1,
        autoHeight:         false,
        autoplay:           autoPlay,
        autoplayTimeout:    5000,
        autoplayHoverPause: true,
		    animateOut:         'fadeOut',
        animateIn:          'fadeIn',
		    lazyLoad:           true,
		    loop:               true,
		    margin:             0,
		    nav:                false,
		    dots:               true,
            navText:            ['<span class="nav-icon icon-aae-left"></span>','<span class="nav-icon icon-aae-right"></span>'],
            onInitialized: function(event){
                jsBannerHeight('.js-bannerslider', '.bannerslider-item .details');

            }
		});


        $owl.on('changed.owl.carousel', function(event) {

            $(".js-bannerslider .owl-dots").hide().stop().fadeIn();

        });



	}

    // js-carouselslider
    $(".js-carouselslider").each(function() {
        var $carousel = $(this);
        if( $carousel.find("> *").length > 1 ) {

            $carousel.owlCarousel({
                autoHeight: false,
                loop:       false,
                margin:     30,
                nav:        false,
                dots:       true,
                responsive:{
                    0:{
                        items:1,
                        slideBy:1
                    },
                    720:{
                        items:2,
                        slideBy:2
                    },
                    992:{
                        items:2,
                        slideBy:2
                    },
                    1200:{
                        items:3,
                        slideBy:3
                    }
                },
                onInitialized: function(event){

                }
            });

            if( $carousel.hasClass("mod-keyboard") ) {
                console.log("hello");
                $(document.documentElement).keyup(function (event) {    
                    var owl = $(".owl-carousel.mod-keyboard");
                    console.log('');
                    // handle cursor keys
                    if (event.keyCode == 37) {
                       // go left
                       owl.trigger('next.owl.carousel');
                    } else if (event.keyCode == 39) {
                       // go right
                       owl.trigger('prev.owl.carousel');
                    }

                });
            }
        }
    });

    if( $(".mod-progress-bar").length > 0 ) {

        var time = 5; // time in seconds

        var $progressBar,
            $bar,
            $elem,
            isPause,
            tick,
            percentTime;

        var progress_bar_slider = $(".mod-progress-bar").owlCarousel({
            items:1,
            onInitialized : progressBar,
            onTranslate : moved,

        });

        function progressBar(elem){
            $elem = $(elem.currentTarget);
            //build progress bar elements
            buildProgressBar();
            //start counting
            start();
        }

        //create div#progressBar and div#bar then prepend to $("#owl-demo")
        function buildProgressBar(){

            $progressBar = $("<div>",{
                id:"progressBar"
            });

            $bar = $("<div>",{
                id:"bar"
            });

            $progressBar.append($bar).prependTo($elem);
        }

        function start() {
            //reset timer
            percentTime = 0;
            isPause = false;
            //run interval every 0.01 second
            tick = setInterval(interval, 10);
        };

        function interval() {
            if(isPause === false){
                percentTime += 1 / time;

                if( percentTime  <= 101 ) {
                    $bar.css({
                        width: percentTime+"%"
                    });
                }
               
                //if percentTime is equal or greater than 100
                if(percentTime >= 100){
                    //slide to next item 
                    progress_bar_slider.trigger('next.owl.carousel')
                }
            }
        }

        //moved callback
        function moved(){
            //clear interval
            clearTimeout(tick);
            //start again
            start();
        }
    }

    
    // twitter widget
    $(".widget-twitter").each(function() {
        var owlTwitter = $(this).find(".widget-twitter-list.owl-carousel").owlCarousel( {
              autoplay      : false
            , autoplaySpeed : 1000
            , items         : 1
            , dots          : false
            , loop          : true
            , mouseDrag     : false
            , autoHeight    : true
            , animateIn     : 'fadeInLeft'
            , animateOut    : 'slideOutRight'
            , onInitialized : function (e) {
                $(e.target).closest('.widget-twitter').find('.num-of-twit').text(e.item.count);
            }
            , onChanged : function(e) {
                console.log(e);
                console.log(e.item);
                var currentItem = e.item._trueCurrent;
                $(e.target).closest('.widget-twitter').find('.curr-twit').text( currentItem );
            }
        } );

        $(this).find('.widget-twitter-nav-next').click(function(e) {
            
            owlTwitter.trigger('next.owl.carousel');

        })
        // Go to the previous item
        $(this).find('.widget-twitter-nav-prev').click(function(e) {
        
            // With optional speed parameter
            // Parameters has to be in square bracket '[]'
            owlTwitter.trigger('prev.owl.carousel');

        });

    });
    // js-sponsors
    $(".js-sponsors").each(function() {
        var $carousel = $(this);
        if( $carousel.find("> *").length > 1 ) {

            $carousel.owlCarousel({
                autoHeight: false,
                loop:       false,
                margin:     30,
                nav:        false,
                dots:       true,
                responsive:{
                    0:{
                        items:2,
                        slideBy:2
                    },
                    720:{
                        items:3,
                        slideBy:3
                    },
                    992:{
                        items:4,
                        slideBy:4
                    }
                },
                onInitialized: function(event){

                }
            });

            if( $carousel.hasClass("mod-keyboard") ) {
                console.log("hello");
                $(document.documentElement).keyup(function (event) {    
                    var owl = $(".owl-carousel.mod-keyboard");
                    console.log('');
                    // handle cursor keys
                    if (event.keyCode == 37) {
                       // go left
                       owl.trigger('next.owl.carousel');
                    } else if (event.keyCode == 39) {
                       // go right
                       owl.trigger('prev.owl.carousel');
                    }

                });
            }
        }
    });


    // Slider
    $('.js-make-slider').owlCarousel({
        items      : 1,
        smartSpeed : 800,
        autoHeight : true
    });

};

( function( $ ) {

	$( document ).ready( function() {

		PIXL8.owlHandler();

	} );

} )( jQuery );