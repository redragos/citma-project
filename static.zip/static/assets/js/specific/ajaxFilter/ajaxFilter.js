( function( $ ){

	var   $resultEndpoint   = cfrequest.resultEndpoint
		, $resultsContainer = $( cfrequest.resultsContainer )
		, fetchResult
		, getFilter

	getFilter = function( additionalData ){
		var filter         = {};
		var checkboxFilters = {};

		$( '.filter-checkbox:checked' ).each( function() {
			var inputName = $(this).attr('name');
			if( typeof checkboxFilters[inputName] === "undefined" ){
				checkboxFilters[inputName]= [];
			}
			checkboxFilters[inputName].push( $(this).val() );
		});

		for( var checkboxFilter in checkboxFilters ) {
			filter[checkboxFilter] = checkboxFilters[checkboxFilter].toString();
		}

		filter.maxRows = cfrequest.maxRows;

		$('.related-filter-field').each( function() {
			if( $(this).length ){
				var inputName = $(this).attr('name');
				filter[inputName] = $(this).val();
			}
		});

		updateURL( filter );

		filter.pageId  = cfrequest.pageId;

		return filter;
	};

	fetchResult = function( additionalData ){
		$.ajax( $resultEndpoint, {
			  method  : "POST"
			, cache   : false
			, data    : getFilter( additionalData )
		} ).done( function( response ) {

			$resultsContainer.html( response );

			// Rebind jquery function
			if( $resultsContainer.find( '.js-show-tooltip' ).length ){
				PIXL8.attachtooltipster( $resultsContainer );
			}

			if( $resultsContainer.find( '.collapsible' ).length ){
				collapsibleHandler( $resultsContainer );
			}

			//for manual load more
			if( $resultsContainer.find( '.load-more-link' ).length ){
				$( "a.load-more-link" ).loadMore();
			}

			if(typeof addthis !== 'undefined') { addthis.layers.refresh(); }

		}).fail(function() {
			alert('Connection failed, please try again later');
			return false;
		});

	};

	updateURL = function( filterDataSet ){
		var url         = [location.protocol, '//', location.host, location.pathname].join('');;
		var firstFilter = true;

		for( var filterData in filterDataSet ) {

			if( filterDataSet[filterData].length ){

				if( firstFilter ){
					url += "?";
					firstFilter = false;
				}else {
					url += "&"
				}

				url += filterData + "=" + filterDataSet[filterData];

			}

		}
		window.history.pushState( {path: url },'', url );
	};

	$( ".contents" ).on( "click", ".filter-checkbox", function( e ){
		e.preventDefault();
		fetchResult();
	});

} )( jQuery );