PIXL8.whosWhoHandler = function( $container ) {

    $('.widget-whos-who-item').each(function() {

        var desc_container = $(this).find('.widget-whos-who-item-desc-text'),
            show_more_btn = '<p class="bottom-link"><a href="#" class="show-excerpt">Read more</a></p>',
            containerHeight = desc_container.outerHeight();
        // if (wordCount > 22) {
        if (containerHeight > 56) {
            desc_container.addClass('excerpt-text');
            //ptext.wrapAll('<div class="excerpt-text"></div>');
            $(this).find('.widget-whos-who-item-desc').append(show_more_btn);
        }
    });

    $('.show-excerpt').on('click', function(e) {
        e.preventDefault();
        var excerptActive = $(this).parent().prev().hasClass('excerpt-text');

        if (!excerptActive) {
            $(this).text('Read more').parent().prev().addClass('excerpt-text');
        } else {
            $(this).text('Show less ').parent().prev().removeClass('excerpt-text');
        }
    });
  
};

( function( $ ) {

    $( document ).ready( function() {

        PIXL8.whosWhoHandler();

    } );

} )( jQuery );