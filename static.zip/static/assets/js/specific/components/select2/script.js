PIXL8.attachSelect2 = function( $container ) {

	

		// js select2
		if ( !$('html').hasClass('mobile') ) {
	        $(".js-custom-select").each(function(e) {
	            var $customselect = $(this);

	            $customselect.select2({
	                placeholder: $customselect.data('placeholder'),
	                minimumResultsForSearch: Infinity,
	                theme: "pixl8"
	            });
	        });
	        $(".js-custom-select-search").each(function(e) {
	            var $customselect = $(this);

	            $customselect.select2({
	                placeholder: $customselect.data('placeholder'),
	                theme: "pixl8"
	            });
	        });

	    };

};

( function( $ ) {

	$( document ).ready( function() {

		PIXL8.attachSelect2( $("body") );

	} );

} )( jQuery );