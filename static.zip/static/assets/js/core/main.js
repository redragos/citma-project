var PIXL8 = function() {

	var menuHandler = function () {

		$( ".js-menu-trigger" ).click( function( e ) {
			e.preventDefault();
			$( ".site-head-nav" ).stop().slideToggle();
			$('.menu-overlay').fadeToggle(200);
			$( this ).find( ".hamburger" ).toggleClass( "is-active" );
		} );



		// nav submenu
		// - append mobile trigger
		$( ".js-subnav-menu" ).closest('.site-head-nav-dropdown').append('<button class="js-subnav-menu-trigger" type="button"></button>')
		$( ".js-subnav-menu-trigger" ).on('click', function(e) {
			e.preventDefault();

			$(this).toggleClass('is-active').closest('li').find('.site-head-subnav').stop().slideToggle();
		});

		// subnav
		$( ".js-subnav-menu" ).hover( function() {

			if (PIXL8.fn.viewport().width > PIXL8.mediaWidth.SM) {
				// if( $('html').hasClass('no-touch') ) {
					$('.menu-overlay').fadeIn(200);
					$('.site-head-subnav').stop().fadeOut(200);


					$(this).find('.site-head-subnav').fadeIn(200);

					var active_menu = $(this).find('.site-head-subnav');

					setTimeout(function(){
						active_menu.addClass('menu-open');
					}, 20);
				// }
			}

		}, function() {
			if (PIXL8.fn.viewport().width > PIXL8.mediaWidth.SM) {
				// if( $('html').hasClass('no-touch') ) {
					$('.site-head-subnav').removeClass('menu-open').stop().fadeOut(200);
					$('.menu-overlay').stop().fadeOut(200);
				// }
			}


		} );

	}

	var formHandler = function () {

		// Collapsible alert
		$( ".js-close-alert" ).click(function(e) {
			e.preventDefault();
			$( this ).closest( ".alert" ).slideUp();
		});

		// File upload
		$( "input[type='file']" ).on("change", function() {
			var holder = $(this).closest('.upload-holder');
			var previousUploads = holder.find('.upload-file-details');
			var fileDetails = this.files;

			if ( !$(this).closest('.form-field').hasClass('upload-holder') || $('html').hasClass('lt-ie10') ) {

				var $me = $(this),
					fileName = $me.val().split('\\').pop();

				if ( $me.siblings( ".file-name" ).is( "input" ) ) {
					$me.siblings( ".file-name" ).val( fileName );
				} else {
					$me.siblings( ".file-name" ).text( fileName );
				}

			} else {

				if ( previousUploads.length ) {
					previousUploads.remove();
					// $(this).val("");
				}

				for ( var x = 0; x < fileDetails.length; x++ ) {
					var fileDetail = fileDetails[x];
					var fileName   = fileDetail.name;
					var fileSize   = fileDetail.size;
					var fileType   = fileDetail.type;
					var fileIcon;
					var sizeInMB   = ( fileSize / ( 1024 * 1024 ) ).toFixed(2);

					switch (true) {

						case ( fileType == 'image/jpeg' || fileType == 'image/png' || fileType == 'image/png' || fileType == 'image/bmp' || fileType == 'image/gif' ):
							fileIcon = 'font-icon-file-image-o';
							break;

						case ( fileType == 'video/avi' || fileType == 'video/quicktime' || fileType == 'video/mpeg' || fileType == 'video/vivo' || fileType == 'video/mp4' ):
							fileIcon = 'font-icon-file-video-o';
							break;

						case ( fileType == 'application/pdf' ):
							fileIcon = 'font-icon-file-pdf-o';
							break;

						case ( fileType == 'application/x-zip-compressed' ):
							fileIcon = 'font-icon-file-zip-o';
							break;

						default:
							fileIcon = 'font-icon-file-o';
							break;

					} /* switch */

					holder.append('<div class="upload-file-details" data-file-index="' + x + '">' +
										'<span class="font-icon ' + fileIcon + ' upload-file-icon"></span>' +

										'<div class="upload-file-content">' +
											'<h5 class="upload-file-name">' + fileName + '</h5>' +
											'<p class="upload-file-size">' + sizeInMB + 'MB</p>' +
											'<a href="#" class="font-icon font-icon-remove upload-file-remove-button"></a>' +
										'</div>' +
									'</div>');
				} /* for */

			} /* else */

		});

		$('.upload-holder').on( 'click', '.upload-file-remove-button', function(e) {
			e.preventDefault();

			var $fileItem    = $(this).closest('.upload-file-details'),
				$fileInput   = $(this).closest('.upload-holder').find('input[type=file]'),
				$fileDetails = $fileInput.files;

			// for ( var x = 0; x < fileDetails.length; x++ ) {
			// 	var $fileDetail = $fileDetails[x];
			// }

			$fileItem.remove();
			$fileInput.val("");
		});

		// Header search form
		$('.js-toggle-search-form').on('click', function(e) {
			e.preventDefault();

			var $mainNavigation = $('.site-head-nav-list'),
				isActive        = $mainNavigation.hasClass('mod-search-form-active');

			if ( isActive ) {
				$mainNavigation.removeClass('mod-search-form-active');
			} else {
				$mainNavigation.addClass('mod-search-form-active');
				setTimeout(function() { 
					$('.site-head-search-form-input').focus();
				}, 1000);
			}
		});

		// Toggle Fieldset
		$('input[type="radio"], input[type="checkbox"]').on('change', function() {

			var $checked     = $('[data-toggle]:checked');
				$not_checked = $('[data-toggle]:not(:checked)');

			$not_checked.each(function() {
				$('[data-field-toggle="' + $(this).data('toggle') + '"]').slideUp();
			});

			$checked.each(function() {
				$('[data-field-toggle="' + $(this).data('toggle') + '"]').slideDown();
			});

		});

		$('select').on('change', function() {

			var $checked     = $('[data-toggle]:selected');
				$not_checked = $('[data-toggle]:not(:selected)');

			$not_checked.each(function() {
				if ( $(this).closest('[data-field-toggle]').length > 0 ) {
					$(this).closest('[data-field-toggle]').find('[data-field-toggle="' + $(this).data('toggle') + '"]').slideUp();
				} else {
					$('[data-field-toggle="' + $(this).data('toggle') + '"]').slideUp();
				}
			});

			$checked.each(function() {
				$('[data-field-toggle="' + $(this).data('toggle') + '"]').slideDown();
			});

		});

		$('.js-toggle-fieldset').on('click', function(e) {
			e.preventDefault();

			$('[data-fieldset="' + $(this).data('fieldset-id') + '"]').slideToggle();
		});

		// On load
		$('[data-toggle]:checked').each(function() {
			$('[data-field-toggle="' + $(this).data('toggle') + '"]').slideDown();
		});

		$('[data-toggle]:selected').each(function() {
			$('[data-field-toggle="' + $(this).data('toggle') + '"]').slideDown();
		});

	}

	// Collapsible, add class .accordion to .collapsible to make it accordion.
	collapsibleHandler = function( $container ) {

		$( ".collapsible", $container ).each(function() {
			var $me = $( this ),
				isAccordion = $me.hasClass( "accordion" );
			$me.find( "> .collapsible-item > .collapsible-item-header > a" ).click( function( e ) {
				e.preventDefault();
				var collapsible_item = $( this ).closest( ".collapsible-item" );
				if ( isAccordion ) {
					collapsible_item.addClass( "is-open" ).find( "> .collapsible-item-content:first" ).slideDown();
					collapsible_item.siblings().removeClass( "is-open" ).find( "> .collapsible-item-content" ).stop().slideUp();
				} else {
					collapsible_item.toggleClass( "is-open" ).find( "> .collapsible-item-content" ).stop().slideToggle();
				}
			});
			if ( isAccordion ) {
				$me.find( "> .collapsible-item.is-open > .collapsible-item-header > a" ).trigger( "click" );
			} else {
				$me.find( "> .collapsible-item.is-open > .collapsible-item-content" ).slideDown();
			}
		});


		// Profile toggle widget
		$('.author.mod-vertical.is-collapsible .author-item-details').each(function() {
			var $thisWidget       = $(this),
				$thisWidgetHeight = $thisWidget.outerHeight(),
				$detailsToggler   = $thisWidget.find('.author-details-toggler'),
				$detailsHeight    = $thisWidget.find('.author-item-details-holder').outerHeight(),
				isCollapsed       = $thisWidget.hasClass('is-collapsed');

			if ( $detailsHeight < 218 ) {
				$detailsToggler.hide();
				$thisWidget.addClass('mod-all-content-displayed');
			}

			if ( isCollapsed ) {
				$thisWidget.css({
					maxHeight: $detailsHeight
				});
			}
		});

		$('.js-toggle-author-details').on('click', function(e) {
			e.preventDefault();

			var $thisWidget    = $(this).closest('.author-item-details'),
				$contentHeight = $thisWidget.find('.author-item-details-holder').outerHeight(),
				isCollapsed    = $thisWidget.hasClass('is-collapsed');

			if ( isCollapsed ) {
				$thisWidget.css({
					maxHeight: ''
				}).removeClass('is-collapsed');
			} else {
				$thisWidget.css({
					maxHeight: $contentHeight
				}).addClass('is-collapsed');
			}
		});

		// Collapsible document
		$('.group-listing.mod-collapsible-document-list .group-listing-item').each(function() {
		    $(this).filter('.is-collapsed').find('.collapsible-document-list-content').show();
		}).on('click', '.js-toggle-document-content', function(e) {
		    e.preventDefault();

		    var $thisItem        = $(this).closest('.group-listing-item'),
		        $thisItemContent = $thisItem.find('.collapsible-document-list-content'),
		        isCollapsed      = $thisItem.hasClass('is-collapsed');

		    if ( isCollapsed ) {
		        $thisItemContent.slideUp({
		            complete: function() {
		                $thisItem.removeClass('is-collapsed');
		            }
		        });
		    } else {
		        $thisItemContent.slideDown();
		        $thisItem.addClass('is-collapsed');
		    }
		});

	}

	// Toggle tabs
	var toggleTabsHandler = function( $container ) {

		var animateTab = function( currentObject ){
			$( currentObject.attr( "href" ) ).fadeIn().addClass( "is-active" ).siblings().hide().removeClass( "is-active" );
			currentObject.parent().addClass( "is-active" ).siblings().removeClass( "is-active" );
			$( currentObject.attr( "href" ) ).find( "> .toggle-tabs-panel-item-header" ).addClass( "is-active" )
				.next( ".toggle-tabs-panel-item-content" ).css( "display", "block" )
				.parent().siblings().find( "> .toggle-tabs-panel-item-header" ).removeClass( "is-active" )
				.next( ".toggle-tabs-panel-item-content" ).hide();
			if ( currentObject.closest( ".toggle-tabs" ).hasClass( "mod-mobile-accordion" ) ) {
				currentObject.closest( ".toggle-tabs" ).find( "> .toggle-tabs-panel > .toggle-tabs-panel-item.is-active > .toggle-tabs-panel-item-header" ).addClass( "is-active" );
			}
		}

		$( ".toggle-tabs-nav a", $container ).click(function(e) {
			var $me = $( this );
			if ( ! $me.closest( ".toggle-tabs" ).hasClass( "mod-tab-links" ) ) {
				e.preventDefault();
				animateTab( $me );
			}
			if ( $me.parent().hasClass( "is-active" ) ) {
				e.preventDefault();
			}
		});

		$( ".toggle-tabs", $container ).each(function() {
			var $me = $( this );
			if ( $me.hasClass( "mod-tab-links" ) ) {
				var isBeforeCurrent = true,
					mobileHeaderBefore = "",
					mobileHeaderAfter = "";
				$me.find( "> .toggle-tabs-panel > .toggle-tabs-panel-item" ).show().addClass( "is-active" ).find( "> .toggle-tabs-panel-item-header" ).addClass( "is-active" );
				$me.find( "> .toggle-tabs-nav li a" ).each( function( i ) {
					if ( $(this).parent().hasClass( "is-active" ) ) {
						isBeforeCurrent = false;
					} else {
						if( isBeforeCurrent ) {
							mobileHeaderBefore += '<div class="toggle-tabs-panel-item"><a href="' + $(this).attr( "href" ) + '" class="toggle-tabs-panel-item-header">' + $(this).text() + '</a></div>';
						} else {
							mobileHeaderAfter += '<div class="toggle-tabs-panel-item"><a href="' + $(this).attr( "href" ) + '" class="toggle-tabs-panel-item-header">' + $(this).text() + '</a></div>';
						}
					}
				});
				$me.find( "> .toggle-tabs-panel" ).prepend( mobileHeaderBefore ).append( mobileHeaderAfter );
			} else {
				animateTab( $me.find( "> .toggle-tabs-nav li.is-active a" ) );
				$me.find( "> .toggle-tabs-panel > .toggle-tabs-panel-item > .toggle-tabs-panel-item-header" ).click( function( e ) {
					e.preventDefault();
					$( this ).addClass( "is-active" ).next( ".toggle-tabs-panel-item-content" ).slideDown()
						.parent().siblings().find( "> .toggle-tabs-panel-item-header.is-active" )
						.removeClass( "is-active" ).next( ".toggle-tabs-panel-item-content" ).slideUp();
				});
			}
		});

		PIXL8.fn.addDebounceResize( function() {
			if ( PIXL8.fn.viewport().width <= PIXL8.mediaWidth.XS ) {
				$( ".mod-mobile-accordion .toggle-tabs-panel .toggle-tabs-panel-item" ).show();
			} else {
				$( ".mod-mobile-accordion .toggle-tabs-panel .toggle-tabs-panel-item" ).not( ".is-active" ).hide();
			}
		});

	}

	// Subnavigation Widget
	var subnavigationWidgetHandler = function() {

		$( ".widget-sub-navigation .has-submenu > a" ).click(function(e) {
			if (! $( this ).parent().hasClass( "is-active" ) ) {
				e.preventDefault();
				$( this ).next(".submenu").slideToggle().parent().toggleClass( "is-active" );
			}
		});
		$( ".widget-sub-navigation .has-submenu.is-active > a" ).next( ".submenu" ).slideDown();

	}


	// Equal Height JS
	var equalHeightHandler = function() {
		function jsEqualHeight(listing, item) {

			listing.find(item).removeAttr('style');

			listing.each(function() {

				var currentTallest = 0,
					 currentRowStart = 0,
					 rowDivs = new Array(),
					 $el,
					 topPosition = 0;
				 $(this).find(item).each(function() {


				   $el = $(this);
				   $el.removeAttr('style');
				   topPosition = $el.position().top;

				   if (currentRowStart != topPosition) {

					 // we just came to a new row.  Set all the heights on the completed row
					 for (currentDiv = 0 ; currentDiv < rowDivs.length ; currentDiv++) {
					   rowDivs[currentDiv].height(currentTallest);
					 }

					 // set the variables for the new row
					 rowDivs.length = 0; // empty the array
					 currentRowStart = topPosition;
					 currentTallest = $el.height();
					 rowDivs.push($el);

				   } else {

					 // another div on the current row.  Add it to the list and check if it's taller
					 rowDivs.push($el);
					 currentTallest = (currentTallest < $el.height()) ? ($el.height()) : (currentTallest);

				  }

				  // do the last row
				   for (currentDiv = 0 ; currentDiv < rowDivs.length ; currentDiv++) {
					 rowDivs[currentDiv].height(currentTallest);
				   }

				 });​
			});


		}

		$('.js-list-equalheight').each(function() {
			var $listing         = $(this),
				item             = $(this).data('listitem');

			PIXL8.fn.addDebounceResize(function() {
				jsEqualHeight($listing, item);
			});
			// init
			jsEqualHeight($listing, item);
		});



	}

	// toggle list styles
	var toggleListHandler = function() {

		$(".js-toggle-grid").on('click',function(e) {
			e.preventDefault();

			var target = $(this).attr('href');

			$('.js-toggle-list[href="'+target+'"]').removeClass('is-active');
			$(this).addClass('is-active');

			$(target).removeAttr('style').removeAttr('class').addClass('article-row js-list-equalheight');
			$(window).trigger( "resize" );
		});

		$(".js-toggle-list").on('click',function(e) {
			e.preventDefault();

			var target = $(this).attr('href');

			$('.js-toggle-grid[href="'+target+'"]').removeClass('is-active');
			$(this).addClass('is-active');

			$(target).removeAttr('style').removeAttr('class').addClass('article-list');
			$(window).trigger( "resize" );
		});

	}


	var ie8Handler = function () {

		$( "input[type='radio'], input[type='checkbox']" ).each(function() {
			if ( $(this).is( ":checked" ) ) {
				$( this ).next( "label" ).toggleClass( "checked" );
			}
		});

		$( "body" ).on( "change", "input[type='checkbox']", function() {
			$(this).next("label").toggleClass("checked");
		});

		$( "body" ).on( "change", "input[type='radio']", function() {
			if ( $( this ).is( ":checked" ) ) {
				$( "input[name='" + $(this).attr( "name" ) + "']" ).next( "label" ).removeClass( "checked" );
				$( this ).next( "label" ).addClass( "checked" );
			}
		});

	}

	return {

		  isIE8: $( "html" ).hasClass( "lt-ie9" )

		, isIE7: $( "html" ).hasClass( "lt-ie8" )

		/* Media queries breakpoints */
		, mediaWidth: {
			  SM: 991
			, XS: 767
		} /* End media queries breakpoints */

		/*
			Public functions, can be accessed from js/specific/ scripts
			PIXL8.fn.addCustomFunction = function() {};
		*/
		, fn: {
			viewport : function() {
				var e = window, a = 'inner';
				if ( ! ( 'innerWidth' in window ) ) {
					a = 'client';
					e = document.documentElement || document.body;
				}
				return { width : e[ a+'Width' ] , height : e[ a+'Height' ] }
			}
			, addDebounceResize: function( funct ) {
				var _afterResized = PIXL8.afterResized;
				PIXL8.afterResized = function() {
					_afterResized();
					funct();
				}
			}
			, attachCollapsible : function( $container ) {
				collapsibleHandler( $container );
			}
			, attachToggleTabs : function( $container ) {
				toggleTabsHandler( $container );
			}
		} /* End general public functions */

		, afterResized: function() {}

		/* Initiate handlers */
		, init: function() {

			var afterResize  = 0;

			equalHeightHandler();
			menuHandler();
			formHandler();
			subnavigationWidgetHandler();
			toggleListHandler();
			collapsibleHandler( $("body") );
			toggleTabsHandler( $("body") );

			if ( this.isIE8 ) {
				ie8Handler();
			}

			$(window).on( "resize", function() {
				clearTimeout( afterResize );
				afterResize = setTimeout( PIXL8.afterResized, 250 );
			});

			// Trigger resize onload to make the other plugin works properly eg. masonry
			$(window).on( "load", function() {
				$(window).trigger( "resize" );
			});

			return this;

		} /* End initiate handlers */

	};

}();

( function( $ ) {

	$( document ).ready( function() {

		PIXL8.init();

	} );

} )( jQuery );