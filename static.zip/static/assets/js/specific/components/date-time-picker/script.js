PIXL8.dateTimePickerHandler = function() {

	$( '.js-date-time-picker' ).datetimepicker({
		format: 'dd/mm/yyyy hh:ii',
		autoclose: true,
		startDate: new Date(),
		todayHighlight: true
	});

};

( function( $ ) {

	$( document ).ready( function() {

		PIXL8.dateTimePickerHandler();

	} );

} )( jQuery );