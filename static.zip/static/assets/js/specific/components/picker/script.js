PIXL8.pickerHandler = function( $container ) {

    $('.custom-datepicker', $container).each(function() {
        var dateFormat   = $(this).data('date-format')      ? $(this).data('date-format')            : 'dd mmmm yyyy';
        var max_val      = $(this).data('end-date')         ? new Date( $(this).data('end-date') )   : '';
        var min_val      = $(this).data('start-date')       ? new Date( $(this).data('start-date') ) : '';
        var offset_date  = ( $(this).data('offset') != "" ) ? $(this).data('offset')                 : false;
        var rel_operator = $(this).data('relative-operator');

        switch ( rel_operator ) {
            case 'gte' :
                min_val = max_val;
                max_val = offset_date;
                break;

            case 'gt':
                min_val = new Date( max_val.setDate( max_val.getDate()+1 ) );
                max_val = offset_date;
                break;

            case 'lte':
                min_val = -(offset_date);
                break;

            case 'lt':
                max_val = new Date( max_val.setDate( max_val.getDate()-1 ) );
                min_val = -(offset_date + 1);
                break;
        }

        var $input = $(this).pickadate({
           // Buttons
            today: '',
            clear: '',
            close: '',
            weekdaysShort: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            selectYears: true,
            selectMonths: true,
            max: max_val,
            min: min_val,
            format: dateFormat,
            onClose: function() {

                if( !$('html').hasClass('lt-ie10')) {
                    $(document.activeElement).blur();
                }
            },
            onSet: function( e ) {

                if( !$('html').hasClass('lt-ie10')) {
                    if( e.select != undefined ) {
                        $(document.activeElement).blur();
                    }
                }
            }
        });
    });

};

( function( $ ) {

    $( document ).ready( function() {

        PIXL8.pickerHandler( $("body") );

    } );

} )( jQuery );


