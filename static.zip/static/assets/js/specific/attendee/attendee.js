( function( $ ){

	// add attendee
	$(".js-add-attendee").on('click', function(e) {
		e.preventDefault();

		var $attendee_form = $(this).closest('form'),
			$attendee_clone = $attendee_form.find('.attendee-details.template').clone(),
			count = $attendee_form.find('.attendee-wrap').data('startcount');

		$attendee_clone.find('h4 .count').text(count);

		$attendee_clone.find('.checkbox').each(function() {
			$(this).find('input[type="checkbox"]').attr('name', $(this).find('input[type="checkbox"]').attr('name') + count);
			$(this).find('input[type="checkbox"]').attr('id', $(this).find('input[type="checkbox"]').attr('id') + count);
			$(this).find('label').attr('for', $(this).find('label').attr('for') + count);
		});
		$attendee_clone.removeClass('template').appendTo( $attendee_form.find('.attendee-wrap') );

		count++;
		$attendee_form.find('.attendee-wrap').data('startcount',count);

	});

	$(".attendee-wrap").on('click', '.js-remove-attendee', function(e) {
		e.preventDefault();

		var $attendee_form = $(this).closest('form')
			count = $attendee_form.find('.attendee-wrap').data('startcount');

		$(this).closest('.attendee-details').hide().remove();
		count--;
		$attendee_form.find('.attendee-wrap').data('startcount',count);


	});


} )( jQuery );