PIXL8.testimonialHandler = function() {

	function getRandomInt(min, max) {
	    return Math.floor(Math.random() * (max - min)) + min;
	}

	$(".js-show-content-tab").click(function(e) {
	    e.preventDefault();
	    var content_wrap = $($(this).attr("href")),
	    content_wrap_height = content_wrap.height();


	    $(this).parent().addClass("is-active").siblings().removeClass("is-active");
	    $($(this).attr("href")).addClass("is-active").siblings().removeClass("is-active");
	    $('.content-tabs-item-container').css('height', content_wrap_height + 'px' );

	});

	$(window).load(function() {
	    $(".js-show-content-tab").eq(getRandomInt(0, $(".js-show-content-tab").length)).trigger("click");
	});

    
};

( function( $ ) {

	$( document ).ready( function() {

		PIXL8.testimonialHandler();

	} );


} )( jQuery );